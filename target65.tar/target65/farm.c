/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_298(unsigned x)
{
    return x + 2425444397U;
}

unsigned addval_145(unsigned x)
{
    return x + 1086558288U;
}

void setval_242(unsigned *p)
{
    *p = 2425379051U;
}

unsigned getval_191()
{
    return 3347662946U;
}

unsigned addval_416(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_105()
{
    return 3284633932U;
}

unsigned getval_294()
{
    return 3347662920U;
}

unsigned getval_490()
{
    return 3347646513U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_320()
{
    return 3286288712U;
}

void setval_168(unsigned *p)
{
    *p = 3682910889U;
}

unsigned getval_183()
{
    return 3286272328U;
}

unsigned getval_156()
{
    return 3247493513U;
}

void setval_474(unsigned *p)
{
    *p = 3531919625U;
}

unsigned addval_134(unsigned x)
{
    return x + 3229925897U;
}

unsigned addval_393(unsigned x)
{
    return x + 3529556617U;
}

unsigned getval_380()
{
    return 3375940233U;
}

unsigned addval_112(unsigned x)
{
    return x + 3524841097U;
}

unsigned getval_175()
{
    return 3229929865U;
}

unsigned getval_300()
{
    return 3251538363U;
}

unsigned getval_199()
{
    return 3372798337U;
}

void setval_176(unsigned *p)
{
    *p = 3372794505U;
}

void setval_354(unsigned *p)
{
    *p = 3229929867U;
}

unsigned getval_472()
{
    return 2425672073U;
}

void setval_394(unsigned *p)
{
    *p = 3372797581U;
}

unsigned addval_430(unsigned x)
{
    return x + 3525889673U;
}

unsigned getval_328()
{
    return 2311307912U;
}

void setval_414(unsigned *p)
{
    *p = 3222848137U;
}

void setval_142(unsigned *p)
{
    *p = 3227566729U;
}

void setval_124(unsigned *p)
{
    *p = 2497743176U;
}

void setval_355(unsigned *p)
{
    *p = 3286239560U;
}

unsigned getval_208()
{
    return 3524841097U;
}

unsigned getval_131()
{
    return 3682913945U;
}

unsigned getval_403()
{
    return 3676360329U;
}

void setval_454(unsigned *p)
{
    *p = 3677933961U;
}

unsigned addval_456(unsigned x)
{
    return x + 3374371208U;
}

unsigned addval_420(unsigned x)
{
    return x + 3286288712U;
}

unsigned addval_487(unsigned x)
{
    return x + 2497743176U;
}

void setval_319(unsigned *p)
{
    *p = 2429454646U;
}

void setval_337(unsigned *p)
{
    *p = 3286272328U;
}

void setval_263(unsigned *p)
{
    *p = 2497743176U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
